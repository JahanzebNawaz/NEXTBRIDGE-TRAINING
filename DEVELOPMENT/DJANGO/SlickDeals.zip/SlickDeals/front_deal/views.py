from django.shortcuts import render
import requests, bs4
from django.http import HttpResponse
# Create your views here.


def front_page_product(request):
    img_url_list = []
    next_enable = True
    page = request.GET.get('page')
    next = request.GET.get('next')
    prev = request.GET.get('prev')

    items_details_list = list()
    
    while next_enable:
        url = 'https://slickdeals.net/?page='+str(page)
        res = requests.get(url)
        try:
            res.raise_for_status()
        except Exception as exc:
            print('There was a problem: %s' % (exc))
        
        res.status_code == requests.codes.ok
        noStarch = bs4.BeautifulSoup(res.text)
        
        src = noStarch.select('.imageContainer img')
        for i in src:
            img_url = i['src']
            if img_url.endswith('.thumb'):
                img_url_list.append({'url': img_url})

        items_details = noStarch.select(".itemImageLink > a:nth-child(3)")
        
        for i, j in zip(items_details[1:], img_url_list):
            j.update({'title': i['title'], 'href': "https://slickdeals.net"+i['href']})
            items_details_list.append(j)
    
        button_disable = noStarch.select('.button.disabled.lastPage')
        print(button_disable)
        next_enable = False
    return render(request, 'front_deal/deals.html', {'data': items_details_list, "page": page})


def set_session(request):
    request.session['session_name'] = "Shahzaib Ali"
    request.session['session_user_auth_key'] = "klklksad-asdsad-1212213-dsffsdf"
    return HttpResponse("<h1>Session is successfully set</h1>")


def get_session(request):
    session_nam = "<h1>" + request.session['session_name'] + "</h1>"
    session_user_auth_key = "<h2>" + request.session['session_user_auth_key'] + "</h1>"
    
    return HttpResponse(session_nam + " " + session_user_auth_key)


def set_cookies(request):
    response = HttpResponse("<h1>COOKIES SET</h1>")
    response.set_cookie(key='id', value=1)
    return response


def get_cookies(request):
    response = request.COOKIES['id']
    return HttpResponse(response)
