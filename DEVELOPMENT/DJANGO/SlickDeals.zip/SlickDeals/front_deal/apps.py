from django.apps import AppConfig


class FrontDealConfig(AppConfig):
    name = 'front_deal'
