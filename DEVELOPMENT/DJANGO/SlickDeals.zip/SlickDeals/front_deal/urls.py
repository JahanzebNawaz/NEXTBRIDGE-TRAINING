from django.urls import path

from . import views

urlpatterns = [
    path('deals/frontpage', views.front_page_product, name='deals'),
    path('set_session', views.set_session, name="set_session"),
    path('get_session', views.get_session, name="get_session"),
    path('set_cookies', views.set_cookies, name="set_cookies"),
    path('get_cookies', views.get_cookies, name="get_cookies"),
    

]
